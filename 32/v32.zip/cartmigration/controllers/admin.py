class Admin:
	_db = None

	def __init__(self, a):
		self._db = None
		print(a)
